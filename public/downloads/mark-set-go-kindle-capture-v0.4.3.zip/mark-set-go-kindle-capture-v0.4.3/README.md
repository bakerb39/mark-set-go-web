# Mark, Set, Go! Kindle Capture v0.4.3

Local browser-OCR proof of concept for capturing content you are authorized to copy/export from Kindle Cloud Reader.

## What changed in 0.4.0

- Keeps the captured Kindle screenshot as the complete visible PDF page.
- Requests Tesseract TSV output in addition to OCR text.
- Uses each OCR word's bounding box to place an invisible searchable/selectable word at the matching PDF position.
- Preserves OCR reading order and line geometry rather than flattening all OCR text into a generic text column.
- Uses the existing Kindle DOM text layer only as a fallback.
- Keeps the working v0.3.1 capture, crop, navigation, page-change verification, and download flow unchanged.

## Test

1. Load the unpacked extension in Chrome.
2. Refresh `https://read.amazon.com/`.
3. Capture **Current spread**.
4. Open the PDF and confirm it still looks exactly like the Kindle page.
5. Try selecting a line of text in the PDF.
6. Import it into Mark, Set, Go! and compare paragraph/chapter formatting with the commercial Kindle-to-PDF result.

Note: the current proof of concept loads Tesseract.js and its English OCR data at runtime, but page-image OCR itself runs in the browser.


## v0.4.3
- Fixes Page Range integer validation in the popup.
- Validates against Kindle total pages when available.
- Seeks bidirectionally from the current page instead of relying on an 80-spread rewind.
- Handles two-page Kindle layouts that can skip an exact page number.


## v0.4.3
- Fixed Page Range UI: the visible From “1” is now a real default value instead of only a placeholder.
- Page Range auto-fills missing From/To values when selected.
