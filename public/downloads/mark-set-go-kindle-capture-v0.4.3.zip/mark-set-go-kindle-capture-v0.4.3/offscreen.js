const sessions=new Map();
const downloadUrls=new Map();

const ocrPending = new Map();
let ocrReadyPromise = null;
let ocrIsReady = false;
let ocrReqSeq = 0;

function getOcrFrame(){ return document.getElementById('ocrFrame'); }
function waitForOcrReady(){
  if (ocrIsReady) return Promise.resolve();
  if (!ocrReadyPromise) {
    ocrReadyPromise = new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Browser OCR engine did not start. Check the extension sandbox/CSP.')), 30000);
      function onMessage(event){
        const m=event.data;
        if(m?.source==='msg-kindle-ocr-sandbox' && m.type==='OCR_SANDBOX_READY'){
          ocrIsReady = true;
          clearTimeout(timer); window.removeEventListener('message', onMessage); resolve();
        }
      }
      window.addEventListener('message', onMessage);
      const frame=getOcrFrame();
      if(frame?.contentWindow) frame.contentWindow.postMessage({source:'msg-kindle-offscreen',type:'PING'}, '*');
    });
  }
  return ocrReadyPromise;
}

window.addEventListener('message', event => {
  const m=event.data;
  if(!m || m.source!=='msg-kindle-ocr-sandbox') return;
  if(m.type==='OCR_SANDBOX_READY'){
    ocrIsReady = true;
    return;
  }
  if(m.type==='OCR_PROGRESS'){
    chrome.runtime.sendMessage({type:'MSG_PROGRESS',text:`Running browser OCR… ${Math.round((m.progress||0)*100)}%`}).catch(()=>{});
    return;
  }
  if(m.type==='OCR_RESULT' || m.type==='OCR_ERROR'){
    const pending=ocrPending.get(m.requestId);
    if(!pending) return;
    ocrPending.delete(m.requestId); clearTimeout(pending.timer);
    if(m.type==='OCR_ERROR') pending.reject(new Error(m.error||'OCR failed.'));
    else pending.resolve({text:m.text||'',confidence:Number(m.confidence||0),words:Array.isArray(m.words)?m.words:[]});
  }
});

async function ocrImage(dataUrl){
  await waitForOcrReady();
  const requestId=`ocr_${Date.now()}_${++ocrReqSeq}`;
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{ocrPending.delete(requestId); reject(new Error('Browser OCR timed out for this page.'));},180000);
    ocrPending.set(requestId,{resolve,reject,timer});
    const frame=getOcrFrame();
    if(!frame?.contentWindow){ clearTimeout(timer); ocrPending.delete(requestId); reject(new Error('OCR sandbox frame unavailable.')); return; }
    frame.contentWindow.postMessage({source:'msg-kindle-offscreen',type:'OCR_IMAGE',requestId,dataUrl}, '*');
  });
}
function dataUrlBytes(dataUrl){ const b64=dataUrl.split(',')[1]; const bin=atob(b64); const out=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) out[i]=bin.charCodeAt(i); return out; }
function strBytes(s){ return new TextEncoder().encode(s); }
function concat(parts){ const n=parts.reduce((a,b)=>a+b.length,0), out=new Uint8Array(n); let o=0; for(const p of parts){out.set(p,o);o+=p.length;} return out; }
async function crop(dataUrl,bounds,viewport,dpr){
  const blob=await (await fetch(dataUrl)).blob(); const bitmap=await createImageBitmap(blob);
  const sx=bitmap.width/(viewport?.width||bitmap.width), sy=bitmap.height/(viewport?.height||bitmap.height);
  const x=Math.max(0,Math.round(bounds.left*sx)), y=Math.max(0,Math.round(bounds.top*sy));
  const w=Math.max(1,Math.min(bitmap.width-x,Math.round(bounds.width*sx))), h=Math.max(1,Math.min(bitmap.height-y,Math.round(bounds.height*sy)));
  const canvas=new OffscreenCanvas(w,h), ctx=canvas.getContext('2d',{alpha:false}); ctx.drawImage(bitmap,x,y,w,h,0,0,w,h);
  const jpeg=await canvas.convertToBlob({type:'image/jpeg',quality:.92});
  const ab=await jpeg.arrayBuffer(); const bytes=new Uint8Array(ab); let binary=''; const chunk=0x8000; for(let i=0;i<bytes.length;i+=chunk) binary+=String.fromCharCode(...bytes.subarray(i,i+chunk));
  return {dataUrl:`data:image/jpeg;base64,${btoa(binary)}`,width:w,height:h};
}

// v0.4.0 PDF text layer
// ----------------------
// The commercial reference PDF normalizes a 1536px-wide Kindle capture to a
// 737.28pt content box with a 24pt page margin.  That produces a 785.28pt-wide
// page and, for the common 1536x881 capture, a 470.88pt page height.  Matching
// that scale is important because downstream PDF importers use font size and
// text geometry as formatting signals.
const PDF_MARGIN_PT = 24;
const PDF_INNER_WIDTH_PT = 737.28;

function normalizeForPdf(s){
  return String(s||'')
    .replace(/\u00A0/g,' ')
    .replace(/[\u2010\u2011]/g,'-')
    .replace(/\u2212/g,'-')
    .replace(/\u2044/g,'/')
    .replace(/[\u200B-\u200D\uFEFF]/g,'');
}

function utf16beHex(s){
  // Identity-H + an identity ToUnicode CMap.  Use UTF-16BE code units, which is
  // the same basic encoding strategy as the working reference PDF.
  let out='';
  for(const ch of normalizeForPdf(s)){
    const cp=ch.codePointAt(0);
    if(cp<=0xFFFF){
      out+=cp.toString(16).padStart(4,'0');
    } else {
      const x=cp-0x10000;
      const hi=0xD800+(x>>10), lo=0xDC00+(x&0x3FF);
      out+=hi.toString(16).padStart(4,'0')+lo.toString(16).padStart(4,'0');
    }
  }
  return out.toUpperCase();
}

function unicodeCodeUnits(s){
  // GlyphLessFont has a default CID width of 500 units per UTF-16 code unit.
  let n=0;
  for(const ch of normalizeForPdf(s)) n += ch.codePointAt(0)>0xFFFF ? 2 : 1;
  return Math.max(1,n);
}

function groupOcrLines(words){
  const groups=new Map();
  for(const w of words||[]){
    const key=`${Number(w.block)||0}:${Number(w.paragraph)||0}:${Number(w.line)||0}`;
    if(!groups.has(key)) groups.set(key,[]);
    groups.get(key).push(w);
  }
  const lines=[];
  for(const ws of groups.values()){
    ws.sort((a,b)=>(Number(a.word)||0)-(Number(b.word)||0) || (Number(a.left)||0)-(Number(b.left)||0));
    const left=Math.min(...ws.map(w=>Number(w.left)||0));
    const top=Math.min(...ws.map(w=>Number(w.top)||0));
    const right=Math.max(...ws.map(w=>(Number(w.left)||0)+(Number(w.width)||0)));
    const bottom=Math.max(...ws.map(w=>(Number(w.top)||0)+(Number(w.height)||0)));
    const text=ws.map(w=>normalizeForPdf(w.text)).filter(Boolean).join(' ');
    if(!text) continue;
    lines.push({
      text,left,top,width:Math.max(1,right-left),height:Math.max(1,bottom-top),
      block:Number(ws[0].block)||0,paragraph:Number(ws[0].paragraph)||0,line:Number(ws[0].line)||0,
      words:ws
    });
  }
  lines.sort((a,b)=>Math.abs(a.top-b.top)>3 ? a.top-b.top : a.left-b.left);
  return lines;
}

function pageGeometry(pg){
  const scale=PDF_INNER_WIDTH_PT/Math.max(1,pg.width);
  const innerW=PDF_INNER_WIDTH_PT;
  const innerH=pg.height*scale;
  return {
    scale,
    innerW,
    innerH,
    pageW:innerW+PDF_MARGIN_PT*2,
    pageH:innerH+PDF_MARGIN_PT*2
  };
}

function makeTextCommands(pg,geom){
  const ocrWords=pg.ocrWords||[];
  const domWords=pg.textLayer||[];
  const {scale,innerH,pageH}=geom;

  if(ocrWords.length){
    const lines=groupOcrLines(ocrWords);
    if(!lines.length) return '';

    const lineInfo=lines.map(ln=>{
      const words=[...ln.words].sort((a,b)=>(Number(a.left)||0)-(Number(b.left)||0));
      // At the normalized reference scale a normal Kindle body line lands near
      // 10pt, while chapter headings land near 14pt naturally from their OCR
      // bounding-box height.
      const fontPt=Math.max(5.5,Math.min(42,ln.height*scale*0.98));
      const baselinePx=ln.top+ln.height*0.84;
      const baselinePt=PDF_MARGIN_PT+innerH-baselinePx*scale;
      return {...ln,words,fontPt,baselinePt};
    }).filter(ln=>ln.words.length);
    if(!lineInfo.length) return '';

    let out='BT\n3 Tr\n';
    let currentLeftPt=0, currentBaselinePt=0, currentFontPt=null;
    let first=true;

    for(const ln of lineInfo){
      if(currentFontPt===null || Math.abs(currentFontPt-ln.fontPt)>0.01){
        out+=`/F0 ${ln.fontPt.toFixed(3)} Tf\n`;
        currentFontPt=ln.fontPt;
      }
      for(let wi=0;wi<ln.words.length;wi++){
        const w=ln.words[wi];
        const text=normalizeForPdf(w.text||'').trim();
        if(!text) continue;
        const leftPt=PDF_MARGIN_PT+Math.max(0,Number(w.left)||0)*scale;
        const widthPt=Math.max(0.5,(Number(w.width)||1)*scale);
        const baselinePt=ln.baselinePt;

        if(first){
          out+=`1 0 0 1 ${leftPt.toFixed(3)} ${baselinePt.toFixed(3)} Tm\n`;
          first=false;
        } else {
          out+=`${(leftPt-currentLeftPt).toFixed(3)} ${(baselinePt-currentBaselinePt).toFixed(3)} Td\n`;
        }

        const wordForPdf=text+' ';
        const nominalWidth=unicodeCodeUnits(wordForPdf)*ln.fontPt*0.5;
        const horizontalScale=Math.max(20,Math.min(400,(widthPt/Math.max(0.1,nominalWidth))*100));
        out+=`${horizontalScale.toFixed(3)} Tz\n[ <${utf16beHex(wordForPdf)}> ] TJ\n`;
        currentLeftPt=leftPt;
        currentBaselinePt=baselinePt;
      }
    }
    out+='ET\n';
    return out;
  }

  // DOM fallback.  Keep the same normalized PDF coordinate system and Unicode
  // text encoding if OCR geometry is unavailable.
  if(domWords.length && pg.bounds?.width && pg.bounds?.height){
    const b=pg.bounds;
    const xScale=pg.width/b.width, yScale=pg.height/b.height;
    const sorted=[...domWords].sort((a,b)=>Math.abs(a.top-b.top)>4?a.top-b.top:a.left-b.left);
    let out='BT\n3 Tr\n', first=true, lastX=0, lastY=0, curFont=null;
    for(const w of sorted){
      const text=normalizeForPdf(w.text||'').trim(); if(!text) continue;
      const leftPx=(w.left-b.left)*xScale;
      const topPx=(w.top-b.top)*yScale;
      const hPx=Math.max(6,(Number(w.fontSize)||16)*yScale);
      const fontPt=Math.max(5.5,Math.min(42,hPx*scale*.98));
      const x=PDF_MARGIN_PT+leftPx*scale;
      const y=PDF_MARGIN_PT+innerH-(topPx+hPx*.84)*scale;
      if(curFont===null || Math.abs(curFont-fontPt)>.01){ out+=`/F0 ${fontPt.toFixed(3)} Tf\n`; curFont=fontPt; }
      if(first){ out+=`1 0 0 1 ${x.toFixed(3)} ${y.toFixed(3)} Tm\n`; first=false; }
      else out+=`${(x-lastX).toFixed(3)} ${(y-lastY).toFixed(3)} Td\n`;
      const widthPt=Math.max(.5,(Number(w.width)||1)*xScale*scale);
      const t=text+' '; const nominal=unicodeCodeUnits(t)*fontPt*.5;
      out+=`${Math.max(20,Math.min(400,widthPt/Math.max(.1,nominal)*100)).toFixed(3)} Tz\n[ <${utf16beHex(t)}> ] TJ\n`;
      lastX=x; lastY=y;
    }
    out+='ET\n';
    return out;
  }

  const raw=normalizeForPdf(pg.ocrText||'').trim();
  if(!raw) return '';
  const fontPt=10, lineHeight=15.84;
  let x=PDF_MARGIN_PT+10.08, y=pageH-PDF_MARGIN_PT-12.64;
  let out=`BT\n3 Tr\n/F0 ${fontPt} Tf\n100 Tz\n`, first=true, lastX=x, lastY=y;
  for(const source of raw.split(/\r?\n/)){
    const ln=source.replace(/\s+/g,' ').trim();
    if(!ln){ y-=lineHeight; continue; }
    if(y<PDF_MARGIN_PT) break;
    if(first){ out+=`1 0 0 1 ${x.toFixed(3)} ${y.toFixed(3)} Tm\n`; first=false; }
    else out+=`${(x-lastX).toFixed(3)} ${(y-lastY).toFixed(3)} Td\n`;
    out+=`[ <${utf16beHex(ln+' ')}> ] TJ\n`;
    lastX=x; lastY=y; y-=lineHeight;
  }
  out+='ET\n';
  return out;
}

function toUnicodeCMap(){
  return strBytes(`/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo\n<<\n  /Registry (Adobe)\n  /Ordering (UCS)\n  /Supplement 0\n>> def\n/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n1 beginbfrange\n<0000> <FFFF> <0000>\nendbfrange\nendcmap\nCMapName currentdict /CMap defineresource pop\nend\nend`);
}

function buildPdf(pages){
  // 1 Catalog, 2 Pages tree, 3 Type0 font, 4 CIDFont descendant,
  // 5 FontDescriptor, 6 ToUnicode CMap, then Image/Content/Page x N.
  // The font has no visible glyph program because the text uses render mode 3
  // (invisible).  Its Identity-H encoding + ToUnicode map supplies robust Unicode
  // extraction without shipping a font file.
  const objects=[]; const pageRefs=[];
  objects[1]=()=>strBytes('<< /Type /Catalog /Pages 2 0 R >>');
  objects[3]=()=>strBytes('<< /Type /Font /Subtype /Type0 /BaseFont /GlyphLessFont /Encoding /Identity-H /DescendantFonts [4 0 R] /ToUnicode 6 0 R >>');
  objects[4]=()=>strBytes('<< /Type /Font /Subtype /CIDFontType2 /BaseFont /GlyphLessFont /CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> /FontDescriptor 5 0 R /CIDToGIDMap /Identity /DW 500 >>');
  objects[5]=()=>strBytes('<< /Type /FontDescriptor /FontName /GlyphLessFont /Flags 5 /FontBBox [0 0 500 1000] /ItalicAngle 0 /Ascent 1000 /Descent -1 /CapHeight 1000 /StemV 80 >>');
  objects[6]=()=>{ const cm=toUnicodeCMap(); return concat([strBytes(`<< /Length ${cm.length} >>\nstream\n`),cm,strBytes('\nendstream')]); };

  for(let i=0;i<pages.length;i++){
    const base=7+i*3, imgObj=base, contentObj=base+1, pageObj=base+2;
    pageRefs.push(`${pageObj} 0 R`);
    const pg=pages[i], img=dataUrlBytes(pg.dataUrl), g=pageGeometry(pg);
    objects[imgObj]=()=>concat([
      strBytes(`<< /Type /XObject /Subtype /Image /Width ${pg.width} /Height ${pg.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${img.length} >>\nstream\n`),
      img,strBytes('\nendstream')
    ]);
    const visible=`q\n${g.innerW.toFixed(3)} 0 0 ${g.innerH.toFixed(3)} ${PDF_MARGIN_PT} ${PDF_MARGIN_PT} cm\n/Im0 Do\nQ\n`;
    const hidden=makeTextCommands(pg,g);
    const content=strBytes(visible+hidden);
    objects[contentObj]=()=>concat([strBytes(`<< /Length ${content.length} >>\nstream\n`),content,strBytes('endstream')]);
    objects[pageObj]=()=>strBytes(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${g.pageW.toFixed(3)} ${g.pageH.toFixed(3)}] /Resources << /XObject << /Im0 ${imgObj} 0 R >> /Font << /F0 3 0 R >> >> /Contents ${contentObj} 0 R >>`);
  }
  objects[2]=()=>strBytes(`<< /Type /Pages /Count ${pages.length} /Kids [${pageRefs.join(' ')}] >>`);

  const header=strBytes('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
  const chunks=[header], offsets=[0]; let pos=header.length;
  for(let i=1;i<objects.length;i++){
    offsets[i]=pos; const body=objects[i]();
    const chunk=concat([strBytes(`${i} 0 obj\n`),body,strBytes('\nendobj\n')]);
    chunks.push(chunk); pos+=chunk.length;
  }
  const xrefPos=pos;
  let xref=`xref\n0 ${objects.length}\n0000000000 65535 f \n`;
  for(let i=1;i<objects.length;i++) xref+=`${String(offsets[i]).padStart(10,'0')} 00000 n \n`;
  xref+=`trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF`;
  chunks.push(strBytes(xref));
  return concat(chunks);
}
chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
  (async()=>{
    if(msg.type==='OFFSCREEN_CROP'){ const r=await crop(msg.dataUrl,msg.bounds,msg.viewport,msg.dpr); sendResponse({ok:true,...r}); return; }
    if(msg.type==='OFFSCREEN_BEGIN'){ sessions.set(msg.sessionId,{title:msg.title,pages:[]}); sendResponse({ok:true}); return; }
    if(msg.type==='OFFSCREEN_ADD_PAGE'){
      const s=sessions.get(msg.sessionId); if(!s) throw new Error('PDF session missing.');
      chrome.runtime.sendMessage({type:'MSG_PROGRESS',text:'Running browser OCR on captured spread…'}).catch(()=>{});
      let ocr={text:'',confidence:0,words:[]};
      try { ocr=await ocrImage(msg.dataUrl); }
      catch(e){
        // Keep DOM text as a fallback, but surface OCR failure so a page does not
        // silently become image-only.
        if(!(msg.textLayer||[]).length) throw e;
      }
      s.pages.push({dataUrl:msg.dataUrl,width:msg.width,height:msg.height,bounds:msg.bounds,textLayer:msg.textLayer||[],ocrText:ocr.text||'',ocrWords:ocr.words||[],ocrConfidence:ocr.confidence||0});
      sendResponse({ok:true,count:s.pages.length,textWords:(msg.textLayer||[]).length,ocrChars:(ocr.text||'').length,ocrWords:(ocr.words||[]).length,ocrConfidence:ocr.confidence||0}); return;
    }
    if(msg.type==='OFFSCREEN_ABORT'){ sessions.delete(msg.sessionId); sendResponse({ok:true}); return; }
    if(msg.type==='OFFSCREEN_FINALIZE'){
      const s=sessions.get(msg.sessionId); if(!s||!s.pages.length) throw new Error('No captured pages available.');
      const bytes=buildPdf(s.pages); const blob=new Blob([bytes],{type:'application/pdf'}); const url=URL.createObjectURL(blob);
      downloadUrls.set(msg.sessionId,url); sessions.delete(msg.sessionId);
      sendResponse({ok:true,url}); return;
    }
    if(msg.type==='OFFSCREEN_RELEASE_URL'){
      const url=downloadUrls.get(msg.sessionId);
      if(url){ URL.revokeObjectURL(url); downloadUrls.delete(msg.sessionId); }
      sendResponse({ok:true}); return;
    }
  })().catch(e=>sendResponse({ok:false,error:e.message||String(e)}));
  return true;
});
