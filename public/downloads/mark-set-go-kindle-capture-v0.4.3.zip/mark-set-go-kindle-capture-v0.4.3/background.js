let current = null;
const sleep = ms => new Promise(r=>setTimeout(r,ms));
const MAX_WHOLE_SPREADS = 2000;

chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
  if(msg.type==='MSG_START_CAPTURE'){
    if(current){ sendResponse({ok:false,error:'A capture is already running.'}); return; }
    current={cancelled:false,tabId:msg.tabId};
    runCapture(msg).finally(()=>{current=null;});
    sendResponse({ok:true}); return;
  }
  if(msg.type==='MSG_CANCEL_CAPTURE'){ if(current) current.cancelled=true; sendResponse({ok:true}); return; }
});
function ui(message){ chrome.runtime.sendMessage(message).catch(()=>{}); }
async function ensureOffscreen(){
  if(await chrome.offscreen.hasDocument()) return;
  await chrome.offscreen.createDocument({url:'offscreen.html',reasons:['BLOBS'],justification:'Assemble captured page images into a local PDF download.'});
}
async function tabMsg(tabId,msg){ return chrome.tabs.sendMessage(tabId,msg); }
function safeName(s){ return (s||'kindle-book').replace(/[<>:"/\\|?*\x00-\x1F]/g,'').replace(/\s+/g,' ').trim().slice(0,120)||'kindle-book'; }

async function captureCrop(tabId,snap){
  const dataUrl=await chrome.tabs.captureVisibleTab(undefined,{format:'jpeg',quality:92});
  await ensureOffscreen();
  const res=await chrome.runtime.sendMessage({type:'OFFSCREEN_CROP',dataUrl,bounds:snap.bounds,viewport:snap.viewport,dpr:snap.devicePixelRatio||1});
  if(!res?.ok) throw new Error(res?.error||'Could not crop Kindle page.');
  return res;
}
function quickHash(s){
  let h=2166136261; const step=Math.max(1,Math.floor(s.length/12000));
  for(let i=0;i<s.length;i+=step){ h^=s.charCodeAt(i); h=Math.imul(h,16777619); }
  return (h>>>0).toString(16)+':'+s.length;
}
async function captureFrame(tabId){ const snap=await tabMsg(tabId,{type:'MSG_SNAPSHOT'}); if(!snap?.ok) throw new Error('Kindle reader not detected.'); const image=await captureCrop(tabId,snap); return {snap,image,hash:quickHash(image.dataUrl)}; }

async function tryMove(tabId,direction,previousHash){
  for(let method=0; method<=5; method++){
    if(current?.cancelled) return {moved:false,cancelled:true};
    await tabMsg(tabId,{type:'MSG_NAVIGATE',direction,method});
    await sleep(method===0?550:420);
    const next=await captureFrame(tabId);
    if(next.hash!==previousHash) return {moved:true,frame:next};
  }
  return {moved:false};
}
async function goBeginning(tabId){
  ui({type:'MSG_PROGRESS',text:'Going to the beginning…'});
  await tabMsg(tabId,{type:'MSG_HOME'}).catch(()=>{}); await sleep(650);
  let frame=await captureFrame(tabId);
  for(let i=0;i<80 && !current.cancelled;i++){
    const moved=await tryMove(tabId,'prev',frame.hash);
    if(!moved.moved) break;
    frame=moved.frame;
  }
  return frame;
}
async function seekPage(tabId,target,frame){
  if(!frame?.snap?.pageNumber) throw new Error('Kindle page numbers were not detected.');

  // Kindle's Home key often jumps close to the beginning and saves hundreds of moves.
  if(target <= 5 && frame.snap.pageNumber > target + 20){
    await tabMsg(tabId,{type:'MSG_HOME'}).catch(()=>{});
    await sleep(650);
    frame=await captureFrame(tabId);
  }

  const seen=new Set();
  for(let guard=0; !current.cancelled && guard<1200; guard++){
    const page=frame.snap.pageNumber;
    if(!page) throw new Error('Kindle lost page-number metadata while seeking the requested range.');
    if(page===target) return frame;

    // In two-page/spread layouts Kindle may jump over an exact page number.
    // Once we have crossed the target, use the current spread as the start.
    if(guard>0 && Math.abs(page-target)<=1) return frame;

    const direction=page<target?'next':'prev';
    const key=`${page}:${frame.hash}`;
    if(seen.has(key)) throw new Error('Kindle reader looped while seeking the requested page range.');
    seen.add(key);
    ui({type:'MSG_PROGRESS',text:`Seeking page ${target}… currently on ${page}`});
    const moved=await tryMove(tabId,direction,frame.hash);
    if(!moved.moved) break;
    const next=moved.frame;
    if(direction==='next' && next.snap.pageNumber>=target) return next;
    if(direction==='prev' && next.snap.pageNumber<=target) return next;
    frame=next;
  }
  throw new Error(`Could not reach Kindle page ${target}.`);
}

async function runCapture(req){
  const {tabId,mode,fromPage,toPage}=req;
  try{
    await ensureOffscreen();
    let frame=await captureFrame(tabId);
    const title=frame.snap.title||'Kindle Book';
    const sessionId=`s_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    await chrome.runtime.sendMessage({type:'OFFSCREEN_BEGIN',sessionId,title});

    if(mode==='whole') frame=await goBeginning(tabId);
    if(mode==='range'){
      if(!frame.snap.pageNumber) throw new Error('Kindle page numbers were not detected. Open Kindle’s page/location display, then try Page Range again.');
      frame=await seekPage(tabId,fromPage,frame);
      if(!frame.snap.pageNumber || frame.snap.pageNumber>toPage) throw new Error('Could not navigate to the requested starting page.');
    }

    let count=0;
    while(!current.cancelled){
      const p=frame.snap.pageNumber;
      if(mode==='range' && p && p>toPage) break;
      const addResult=await chrome.runtime.sendMessage({type:'OFFSCREEN_ADD_PAGE',sessionId,dataUrl:frame.image.dataUrl,width:frame.image.width,height:frame.image.height,bounds:frame.snap.bounds,textLayer:frame.snap.textLayer||[]});
      if(!addResult?.ok) throw new Error(addResult?.error||'OCR/PDF page processing failed.');
      count++;
      if(addResult.ocrChars!=null){
        ui({type:'MSG_PROGRESS',text:`OCR captured ${addResult.ocrChars.toLocaleString()} characters${addResult.ocrConfidence?` · ${Math.round(addResult.ocrConfidence)}% confidence`:''}`,count,percent:Math.min(95,8+count*3)});
      }
      const total=mode==='range' ? (toPage-fromPage+1) : frame.snap.totalPages || null;
      const pct=mode==='current'?90:total&&p?Math.min(96,((p-(mode==='range'?fromPage:1)+1)/total)*100):Math.min(94,5+Math.log2(count+1)*10);
      ui({type:'MSG_PROGRESS',text:p?`Captured Kindle page ${p}`:`Captured spread ${count}`,count,percent:pct});
      if(mode==='current') break;
      if(mode==='range' && p && p>=toPage) break;
      if(count>=MAX_WHOLE_SPREADS) throw new Error(`Safety stop reached ${MAX_WHOLE_SPREADS} spreads.`);
      const moved=await tryMove(tabId,'next',frame.hash);
      if(!moved.moved) break;
      frame=moved.frame;
    }
    if(current.cancelled){ await chrome.runtime.sendMessage({type:'OFFSCREEN_ABORT',sessionId}); ui({type:'MSG_ERROR',error:'Capture canceled.'}); return; }
    if(!count) throw new Error('No Kindle pages were captured.');
    ui({type:'MSG_PROGRESS',text:'Building searchable PDF…',count,percent:97});
    const filename=`${safeName(title)}.pdf`;
    const result=await chrome.runtime.sendMessage({type:'OFFSCREEN_FINALIZE',sessionId,filename});
    if(!result?.ok || !result.url) throw new Error(result?.error||'Could not create PDF.');
    try {
      await chrome.downloads.download({url:result.url,filename,saveAs:true});
    } finally {
      // Delay release slightly so Chrome has time to claim the Blob URL.
      setTimeout(()=>chrome.runtime.sendMessage({type:'OFFSCREEN_RELEASE_URL',sessionId}).catch(()=>{}),15000);
    }
    ui({type:'MSG_DONE',count,filename});
  }catch(e){ ui({type:'MSG_ERROR',error:e?.message||String(e)}); }
}
