let workerPromise = null;

function send(message) {
  parent.postMessage({ source: 'msg-kindle-ocr-sandbox', ...message }, '*');
}

async function getWorker() {
  if (!workerPromise) {
    workerPromise = Tesseract.createWorker('eng', 1, {
      logger: m => {
        if (typeof m?.progress === 'number') {
          send({ type: 'OCR_PROGRESS', progress: m.progress, status: m.status || 'OCR' });
        }
      }
    });
  }
  return workerPromise;
}

function collectWordsFromBlocks(blocks) {
  const words = [];
  if (!Array.isArray(blocks)) return words;

  const box = node => {
    const b = node?.bbox || node?.box || node?.boundingBox || {};
    const x0 = Number(b.x0 ?? b.left ?? 0);
    const y0 = Number(b.y0 ?? b.top ?? 0);
    const x1 = Number(b.x1 ?? (x0 + Number(b.width || 0)));
    const y1 = Number(b.y1 ?? (y0 + Number(b.height || 0)));
    return { left:x0, top:y0, width:Math.max(0,x1-x0), height:Math.max(0,y1-y0) };
  };

  blocks.forEach((block, bi) => {
    const paragraphs = block?.paragraphs || [];
    paragraphs.forEach((para, pi) => {
      const lines = para?.lines || [];
      lines.forEach((line, li) => {
        const lineWords = line?.words || [];
        lineWords.forEach((word, wi) => {
          const text = String(word?.text || '').trim();
          if (!text) return;
          const b = box(word);
          if (!(b.width > 0 && b.height > 0)) return;
          words.push({
            text,
            ...b,
            confidence: Number(word?.confidence ?? word?.conf ?? 0),
            block: bi + 1,
            paragraph: pi + 1,
            line: li + 1,
            word: wi + 1
          });
        });
      });
    });
  });

  return words;
}

window.addEventListener('message', async event => {
  const msg = event.data;
  if (!msg || msg.source !== 'msg-kindle-offscreen') return;

  if (msg.type === 'PING') {
    send({ type: 'OCR_SANDBOX_READY' });
    return;
  }

  if (msg.type !== 'OCR_IMAGE') return;
  try {
    const worker = await getWorker();
    // Request TSV explicitly so we get word positions + line/paragraph IDs.
    const result = await worker.recognize(msg.dataUrl, {}, { text: true, blocks: true });
    const words = collectWordsFromBlocks(result?.data?.blocks || []);
    send({
      type: 'OCR_RESULT',
      requestId: msg.requestId,
      text: result?.data?.text || '',
      confidence: Number(result?.data?.confidence || 0),
      words
    });
  } catch (e) {
    send({ type: 'OCR_ERROR', requestId: msg.requestId, error: e?.message || String(e) });
  }
});

send({ type: 'OCR_SANDBOX_READY' });
