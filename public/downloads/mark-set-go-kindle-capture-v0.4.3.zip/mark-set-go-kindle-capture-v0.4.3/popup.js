const $ = s => document.querySelector(s);
const captureBtn = $('#captureBtn');
const cancelBtn = $('#cancelBtn');
const readerInfo = $('#readerInfo');
const rangeFields = $('#rangeFields');
const progressWrap = $('#progressWrap');
const progressBar = $('#progressBar');
const progressText = $('#progressText');
const progressCount = $('#progressCount');
let lastSnapshot = null;

function positiveIntFromInput(input){
  if(!input) return null;
  const n=input.valueAsNumber;
  return Number.isSafeInteger(n) && n > 0 ? n : null;
}

function activeMode(){ return document.querySelector('input[name="mode"]:checked').value; }
function syncModeUI(){
  const mode = activeMode();
  rangeFields.classList.toggle('hidden', mode !== 'range');
  document.querySelectorAll('.option').forEach(el => el.classList.toggle('selected', el.querySelector('input').checked));
  if(mode === 'range'){
    const from = $('#fromPage');
    const to = $('#toPage');
    if(!String(from.value || '').trim()) from.value = '1';
    if(!String(to.value || '').trim()){
      const max = Number(lastSnapshot?.totalPages) || 20;
      to.value = String(Math.min(20, max));
    }
  }
}
document.querySelectorAll('input[name="mode"]').forEach(r => r.addEventListener('change', syncModeUI));

async function getTab(){ const [tab] = await chrome.tabs.query({active:true,currentWindow:true}); return tab; }
async function inspect(){
  try{
    const tab = await getTab();
    if(!tab?.id || !/^https:\/\/read\.amazon\./i.test(tab.url||'')) throw new Error('Open Kindle Cloud Reader first.');
    const snap = await chrome.tabs.sendMessage(tab.id,{type:'MSG_SNAPSHOT'});
    if(!snap?.ok) throw new Error(snap?.error || 'Reader surface not detected yet.');
    lastSnapshot=snap;
    readerInfo.className='reader-info ready';
    const page = snap.pageNumber ? ` · Page ${snap.pageNumber}${snap.totalPages ? ` of ${snap.totalPages}`:''}` : '';
    if(snap.totalPages){
      $('#fromPage').max=String(snap.totalPages);
      $('#toPage').max=String(snap.totalPages);
    }
    readerInfo.textContent = `${snap.title || 'Kindle book detected'}${page}`;
    captureBtn.disabled=false;
  }catch(err){
    readerInfo.className='reader-info error'; readerInfo.textContent=err.message; captureBtn.disabled=true;
  }
}

captureBtn.addEventListener('click', async()=>{
  const mode=activeMode();
  const fromPage=positiveIntFromInput($('#fromPage'));
  const toPage=positiveIntFromInput($('#toPage'));
  const maxPage=Number(lastSnapshot?.totalPages)||null;
  if(mode==='range' && (fromPage===null || toPage===null || toPage < fromPage || (maxPage && (fromPage>maxPage || toPage>maxPage)))){
    readerInfo.className='reader-info error';
    readerInfo.textContent=maxPage
      ? `Range check failed (From=${fromPage ?? 'invalid'}, To=${toPage ?? 'invalid'}, Max=${maxPage}).`
      : `Range check failed (From=${fromPage ?? 'invalid'}, To=${toPage ?? 'invalid'}).`;
    return;
  }
  const tab=await getTab();
  progressWrap.classList.remove('hidden'); progressText.textContent='Starting capture…'; progressCount.textContent=''; progressBar.style.width='3%';
  captureBtn.classList.add('hidden'); cancelBtn.classList.remove('hidden');
  const res=await chrome.runtime.sendMessage({type:'MSG_START_CAPTURE',tabId:tab.id,mode,fromPage,toPage});
  if(!res?.ok){ finishError(res?.error||'Capture could not start.'); }
});

cancelBtn.addEventListener('click', async()=>{ await chrome.runtime.sendMessage({type:'MSG_CANCEL_CAPTURE'}); cancelBtn.disabled=true; progressText.textContent='Canceling…'; });

chrome.runtime.onMessage.addListener(msg=>{
  if(msg.type==='MSG_PROGRESS'){
    progressWrap.classList.remove('hidden');
    progressText.textContent=msg.text||'Capturing…';
    progressCount.textContent=msg.count ? `${msg.count} spread${msg.count===1?'':'s'}` : '';
    if(msg.percent!=null) progressBar.style.width=`${Math.max(2,Math.min(100,msg.percent))}%`;
  }
  if(msg.type==='MSG_DONE'){
    progressText.textContent=`PDF saved · ${msg.count} spread${msg.count===1?'':'s'}`; progressBar.style.width='100%';
    cancelBtn.classList.add('hidden'); cancelBtn.disabled=false; captureBtn.classList.remove('hidden');
  }
  if(msg.type==='MSG_ERROR') finishError(msg.error||'Capture failed.');
});
function finishError(text){ readerInfo.className='reader-info error'; readerInfo.textContent=text; progressText.textContent='Stopped'; cancelBtn.classList.add('hidden'); cancelBtn.disabled=false; captureBtn.classList.remove('hidden'); }

syncModeUI(); inspect();
