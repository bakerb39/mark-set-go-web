(() => {
  const sleep = ms => new Promise(r=>setTimeout(r,ms));

  function accessibleDocs(win=window, offsetX=0, offsetY=0, out=[]){
    try{
      out.push({doc:win.document,win,offsetX,offsetY});
      for(const frame of win.document.querySelectorAll('iframe')){
        try{
          const r=frame.getBoundingClientRect();
          if(frame.contentWindow) accessibleDocs(frame.contentWindow, offsetX+r.left, offsetY+r.top, out);
        }catch{}
      }
    }catch{}
    return out;
  }
  function isVisible(el){
    try{ const r=el.getBoundingClientRect(), s=getComputedStyle(el); return r.width>40&&r.height>40&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)>0; }catch{return false}
  }
  function collectRenderRects(){
    const rects=[];
    for(const ctx of accessibleDocs()){
      const candidates=[...ctx.doc.querySelectorAll('canvas, svg, img')];
      for(const el of candidates){
        if(!isVisible(el)) continue;
        const r=el.getBoundingClientRect();
        const area=r.width*r.height;
        if(area < innerWidth*innerHeight*0.035) continue;
        const left=ctx.offsetX+r.left, top=ctx.offsetY+r.top, right=left+r.width, bottom=top+r.height;
        if(right<0||bottom<0||left>innerWidth||top>innerHeight) continue;
        rects.push({left,top,right,bottom,area});
      }
    }
    return rects;
  }
  function readerBounds(){
    const rects=collectRenderRects();
    if(rects.length){
      rects.sort((a,b)=>b.area-a.area);
      const maxArea=rects[0].area;
      const selected=rects.filter(r=>r.area>=maxArea*.28 && r.top>25 && r.bottom<innerHeight+25);
      const left=Math.max(0,Math.min(...selected.map(r=>r.left)));
      const top=Math.max(0,Math.min(...selected.map(r=>r.top)));
      const right=Math.min(innerWidth,Math.max(...selected.map(r=>r.right)));
      const bottom=Math.min(innerHeight,Math.max(...selected.map(r=>r.bottom)));
      if(right-left>200 && bottom-top>200) return {left,top,width:right-left,height:bottom-top};
    }
    // Conservative center fallback: excludes most Kindle chrome.
    return {left:Math.round(innerWidth*.08),top:Math.round(innerHeight*.08),width:Math.round(innerWidth*.84),height:Math.round(innerHeight*.84)};
  }

  function collectVisibleWords(bounds){
    const words=[];
    const maxWords=12000;
    const excluded=new Set(['SCRIPT','STYLE','NOSCRIPT','TEXTAREA','INPUT','SELECT','OPTION']);
    for(const ctx of accessibleDocs()){
      let walker;
      try{
        walker=ctx.doc.createTreeWalker(ctx.doc.body||ctx.doc.documentElement, NodeFilter.SHOW_TEXT);
      }catch{ continue; }
      let node;
      while((node=walker.nextNode()) && words.length<maxWords){
        const parent=node.parentElement;
        if(!parent || excluded.has(parent.tagName)) continue;
        const raw=node.nodeValue||'';
        if(!raw.trim()) continue;
        let style;
        try{ style=ctx.win.getComputedStyle(parent); }catch{ continue; }
        if(style.display==='none'||style.visibility==='hidden'||Number(style.opacity||1)===0) continue;
        const fontSize=Math.max(7,parseFloat(style.fontSize)||16);
        const fontWeight=String(style.fontWeight||'400');
        const fontStyle=String(style.fontStyle||'normal');
        const re=/\S+/g;
        let m;
        while((m=re.exec(raw)) && words.length<maxWords){
          try{
            const range=ctx.doc.createRange();
            range.setStart(node,m.index); range.setEnd(node,m.index+m[0].length);
            const rect=range.getBoundingClientRect();
            if(!rect || rect.width<=0 || rect.height<=0) continue;
            const left=ctx.offsetX+rect.left, top=ctx.offsetY+rect.top, right=left+rect.width, bottom=top+rect.height;
            if(right<bounds.left || left>bounds.left+bounds.width || bottom<bounds.top || top>bounds.top+bounds.height) continue;
            words.push({
              text:m[0], left, top, width:rect.width, height:rect.height,
              fontSize, bold:(fontWeight==='bold'||Number(fontWeight)>=600), italic:fontStyle.includes('italic')
            });
          }catch{}
        }
      }
    }
    words.sort((a,b)=>Math.abs(a.top-b.top)>3?a.top-b.top:a.left-b.left);
    return words;
  }
  function allVisibleText(){
    let best='';
    for(const ctx of accessibleDocs()){
      try{ const t=(ctx.doc.body?.innerText||'').replace(/\s+/g,' ').trim(); if(t.length>best.length) best=t; }catch{}
    }
    return best;
  }
  function parsePage(text){
    const patterns=[/Page\s+(\d+)\s+of\s+(\d+)/i,/Page\s+(\d+)/i,/pages?\s+(\d+)\s*[–-]\s*(\d+)\s+of\s+(\d+)/i];
    for(const p of patterns){ const m=text.match(p); if(m){ if(m.length===4) return {pageNumber:+m[1],totalPages:+m[3]}; return {pageNumber:+m[1],totalPages:m[2]?+m[2]:null}; } }
    return {pageNumber:null,totalPages:null};
  }
  function title(){
    const docTitle=(document.title||'').replace(/\s*[|–-]\s*Kindle.*$/i,'').trim();
    return docTitle || 'Kindle Book';
  }
  function snapshot(){
    const text=allVisibleText(); const page=parsePage(text); const b=readerBounds();
    const textLayer=collectVisibleWords(b);
    return {ok:true,title:title(),...page,bounds:b,viewport:{width:innerWidth,height:innerHeight},devicePixelRatio:devicePixelRatio||1,textSample:text.slice(0,280),textLayer};
  }
  function findButton(direction){
    const selectors=direction==='next' ? [
      "[aria-label='Next Page']","[aria-label='Next page']","[aria-label='Next']","[data-testid='kindle-navigator-next']","[data-kindle-next-page]",".rightArrow",".kp-notebook-page-turn-right"
    ] : [
      "[aria-label='Previous Page']","[aria-label='Previous page']","[aria-label='Previous']","[data-testid='kindle-navigator-previous']","[data-kindle-previous-page]",".leftArrow",".kp-notebook-page-turn-left"
    ];
    for(const ctx of accessibleDocs()) for(const s of selectors){ const el=ctx.doc.querySelector(s); if(el&&isVisible(el)) return {el,win:ctx.win}; }
    return null;
  }
  function mouseClick(el,win){
    const r=el.getBoundingClientRect(), x=r.left+r.width/2,y=r.top+r.height/2;
    for(const type of ['pointerdown','mousedown','pointerup','mouseup','click']){
      const C=type.startsWith('pointer') ? win.PointerEvent : win.MouseEvent;
      try{el.dispatchEvent(new C(type,{bubbles:true,cancelable:true,clientX:x,clientY:y,button:0,buttons:type.includes('down')?1:0,pointerType:'mouse'}));}catch{}
    }
    try{el.click();}catch{}
  }
  function dispatchKey(key){
    const code=key==='ArrowRight'?'ArrowRight':key==='ArrowLeft'?'ArrowLeft':key;
    for(const target of [document.activeElement,document.body,document,window]){
      if(!target?.dispatchEvent) continue;
      for(const type of ['keydown','keyup']) try{target.dispatchEvent(new KeyboardEvent(type,{key,code,bubbles:true,cancelable:true}));}catch{}
    }
  }
  async function navigate(direction,method){
    const sign=direction==='next'?1:-1;
    if(method===0){ const b=findButton(direction); if(!b) return {ok:false}; mouseClick(b.el,b.win); return {ok:true}; }
    if(method===1){ dispatchKey(direction==='next'?'ArrowRight':'ArrowLeft'); return {ok:true}; }
    if(method===2){ dispatchKey(direction==='next'?'PageDown':'PageUp'); return {ok:true}; }
    if(method===3){ window.scrollBy({left:sign*Math.max(500,innerWidth*.8),top:0,behavior:'instant'}); return {ok:true}; }
    if(method===4){
      const x=direction==='next'?innerWidth-24:24,y=innerHeight*.52,el=document.elementFromPoint(x,y)||document.body;
      for(const type of ['pointerdown','mousedown','pointerup','mouseup','click']) try{el.dispatchEvent(new MouseEvent(type,{bubbles:true,cancelable:true,clientX:x,clientY:y,button:0}));}catch{}
      return {ok:true};
    }
    if(method===5){
      const startX=direction==='next'?innerWidth*.78:innerWidth*.22,endX=direction==='next'?innerWidth*.22:innerWidth*.78,y=innerHeight*.55;
      const el=document.elementFromPoint(startX,y)||document.body;
      for(const [type,x] of [['pointerdown',startX],['pointermove',(startX+endX)/2],['pointerup',endX]]) try{el.dispatchEvent(new PointerEvent(type,{bubbles:true,cancelable:true,clientX:x,clientY:y,pointerType:'touch',isPrimary:true}));}catch{}
      return {ok:true};
    }
    return {ok:false};
  }
  async function home(){ dispatchKey('Home'); await sleep(700); return snapshot(); }

  chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
    if(msg.type==='MSG_SNAPSHOT'){ try{sendResponse(snapshot());}catch(e){sendResponse({ok:false,error:e.message});} return; }
    if(msg.type==='MSG_NAVIGATE'){ navigate(msg.direction,msg.method).then(sendResponse); return true; }
    if(msg.type==='MSG_HOME'){ home().then(sendResponse); return true; }
  });
})();
